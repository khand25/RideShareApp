package edu.uga.cs.ridesharingapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
/**
 * The LoginPage activity will be responsible to loading
 * up the login page to allow for a user to login as either
 * a rider or driver into a previously registered account.*/
public class LoginPage extends AppCompatActivity {

    public static final String TAG = "LoginPage";
    private FirebaseAuth mAuth;
    private EditText editTextEmail, editTextPassword;
    private Button buttonLogin, buttonGoToRegister;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login_page);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editTextEmail = findViewById(R.id.editTextEmailLogin);
        editTextPassword = findViewById(R.id.editTextPasswordLogin);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonGoToRegister = findViewById(R.id.buttonGoToRegister);
        // Used to handle saving the current state of the app, whenever the
        // user decides to change the orientation of the app or switch to another
        // app in the middle of execution

        if (savedInstanceState != null) {
            editTextEmail.setText(savedInstanceState.getString("email", ""));
            editTextPassword.setText(savedInstanceState.getString("password", ""));

            int selectedRole = savedInstanceState.getInt("selectedRole", -1);
            if (selectedRole != -1) {
                RadioButton selectedButton = findViewById(selectedRole);
                if (selectedButton != null) {
                    selectedButton.setChecked(true);
                }
            }
        }

        // Grab the "Users" node reference programmatically from FireBase
        databaseReference = FirebaseDatabase.getInstance().getReference("Users");
        // When the user clicks on the login button, exectue the loginUserImproved
        // function to authenticate and allow for the user to either progress to the
        // next screen or not.
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginUserImproved();
            }
        });

        //Whenver the user clicks on the register button, then make them
        // transistion to the RegisterActvity screen
        buttonGoToRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Redirect to RegisterActivity
                startActivity(new Intent(LoginPage.this, RegisterActivity.class));
            }
        });
        /*TextView textView = findViewById( R.id.textView );

        mAuth = FirebaseAuth.getInstance();
        String email = "dawg@mail.com";
        String password = "password";

        mAuth.signInWithEmailAndPassword( email, password )
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d( TAG, "signInWithEmail:success" );
                            FirebaseUser user = mAuth.getCurrentUser();
                        }
                        else {
                            // If sign in fails, display a message to the user.
                            Log.d( TAG, "signInWithEmail:failure", task.getException() );
                            Toast.makeText( LoginPage.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference( "message" );

        // Read from the database value for ”message”
        myRef.addValueEventListener( new ValueEventListener() {
            @Override
            public void onDataChange( DataSnapshot dataSnapshot ) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String message = dataSnapshot.getValue( String.class );

                Log.d( TAG, "Read message: " + message );
                textView.setText( message );
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.d( TAG, "Failed to read value.", error.toException() );
            }
        }); */

    } //onCreate
    /**
     * Function that will be used to initiate login a user to the
     * Firebase realtime database.*/
    private void loginUser() {
        // Gather the text entered by the user in the edit text boxes for
        // valid emails and passwords inputs
        String emailInput = editTextEmail.getText().toString().trim();
        String passwordInput = editTextPassword.getText().toString().trim();
        // Have a way to ensure empty input into both edit textboxes is not allowed
        if (TextUtils.isEmpty(emailInput)) {
            editTextEmail.setError("Email is required");
            return;
        }

        if (TextUtils.isEmpty(passwordInput)) {
            editTextPassword.setError("Password is required");
            return;
        }

        // Check user credentials from Firebase Database
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // This boolean variable will dictate whether a User email and password
                // is indeed found in the RealTimeDatabase from Firebase list of
                // registered User. If found then set to true or false otherwise.
                boolean found = false;

                for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                    // gather the User node reference  containing
                    // all possible registered users with their
                    // emails and passwords combinations from the realtime database on
                    // Firebase
                    User user = userSnapshot.getValue(User.class);
                    // Apply hashing scheme to user entered password for security
                    // purposes!
                    String hashedInputPassword = hashPassword(passwordInput);
                    // if both the entered email and now encrypted input password match the
                    // the one from the User node in the database, then set found boolean
                    // variable to true otherwise keep it false
                    if (user != null && user.email.equals(emailInput) && user.password.equals(hashedInputPassword)) {
                        found = true;
                        break;
                    }
                }
                // if found == true then post a simple toast message that displays login
                // successful and navigate to the rider screen or driver screen depending
                // on what radio button the user decided to enter in.

                if (found) {
                    Toast.makeText(LoginPage.this, "Login successful!", Toast.LENGTH_SHORT).show();
                    // Navigate to Rider Activity when someone clicks on the rider option
                    // else transition to the driver screen 1 when the user clicks on the driver
                    // radio button
                    // someone logins in the first time
                    RadioGroup radioGroup = findViewById(R.id.radioGroup);
                    // get the id of the selected radio button by the user
                    int selectedId = radioGroup.getCheckedRadioButtonId();
                    String selectedText = null;
                    if (selectedId != -1) {
                        // grab a reference to the selected radio button programitcally
                        RadioButton selectedRadioButton = findViewById(selectedId);
                        // grab the text value of the selected radio button
                        selectedText = selectedRadioButton.getText().toString();
                    }
                    // Navigate to Rider Activity when someone clicks on the rider option
                    // else transition to the Driver screen 1 when the user clicks on the driver
                    // radio button
                    if (selectedText.equalsIgnoreCase("Rider")) {
                        startActivity(new Intent(LoginPage.this, RiderActivity1.class));
                        finish();
                    } else {
                        startActivity(new Intent (LoginPage.this,DriverActivity1.class));
                        finish();
                    }
                } else {
                    // otherwise display a short toast message indicating login was unsucessful
                    // as no user email and password combination matches the one from the database
                    Toast.makeText(LoginPage.this, "Invalid email or password", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(LoginPage.this, "Database Error", Toast.LENGTH_SHORT).show();
            }
        });
    } //loginUser
    /**
     * Main helper function responsible for properly checking, gathering
     * and verifying a user entered email and password combination in the
     * User's node in Firebase. If verified properly, then the user will
     * be able to transition to the next screen as login in or fail to login*/
    private void loginUserImproved() {
        // Gather the text entered by the user in the edit text boxes for
        // valid emails and passwords inputs
        String emailInput = editTextEmail.getText().toString().trim();
        String passwordInput = editTextPassword.getText().toString().trim();
        // Error checking set of if statements where the user must enter a valid
        // email, and passwords with appropriate 6 or more character lengths.
        if (TextUtils.isEmpty(emailInput)) {
            editTextEmail.setError("Email is required");
            return;
        }

        if (TextUtils.isEmpty(passwordInput)) {
            editTextPassword.setError("Password is required");
            return;
        }

        // Initialize FirebaseAuth instance
        mAuth = FirebaseAuth.getInstance();
        // call FireBases signInWithEmailAndPassword function to
        // appropriate call the authentication of a user to the database
        mAuth.signInWithEmailAndPassword(emailInput, passwordInput)
                .addOnCompleteListener(LoginPage.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Login success
                            Toast.makeText(LoginPage.this, "Login successful!", Toast.LENGTH_SHORT).show();

                            // Get selected radio button value as either a rider or driver
                            RadioGroup radioGroup = findViewById(R.id.radioGroup);
                            int selectedId = radioGroup.getCheckedRadioButtonId();
                            String selectedText = null;

                            if (selectedId != -1) {
                                RadioButton selectedRadioButton = findViewById(selectedId);
                                selectedText = selectedRadioButton.getText().toString();
                            }

                            // Navigate to the appropriate screen based upon if the user
                            // wants to be a Rider or driver
                            if ("Rider".equalsIgnoreCase(selectedText)) {
                                startActivity(new Intent(LoginPage.this, RiderActivity1.class));
                            } else {
                                startActivity(new Intent(LoginPage.this, DriverActivity1.class));
                            }

                            finish();

                        } else {
                            // Login failed, hence show the failed toast message
                            Toast.makeText(LoginPage.this, "Login failed: " + task.getException().getMessage(),
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    // User Model class to dictate how the User Node in the Firebase
    // realtime database should actually look like
    public static class User {
        public String email;
        public String password;

        public User() {
            // Required empty constructor
        }

        public User(String email, String password) {
            this.email = email;
            this.password = password;
        }
    }

    /*** A way in which we can encrypt the password for the User before storing
    it in the RealTimeDatabase.
     * @param password which represents the user entered password we wish
     *  to hash.
     * @return the hashed password to store into the database*/
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();

            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }

            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putString("email", editTextEmail.getText().toString());
        outState.putString("password", editTextPassword.getText().toString());

        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        int selectedId = radioGroup.getCheckedRadioButtonId();
        outState.putInt("selectedRole", selectedId);
    }

}