package edu.uga.cs.ridesharingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/**
 * The purpose of this class is to allow drivers to view available unaccepted
 * ride requests created by Drivers and to accept them if it follows the driver's
 * availability */
public class DriverActivity2 extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RideRequestAdapter adapter;
    private List<RideRequest> rideRequests;
    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_driver2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button logoutButton = findViewById(R.id.logoutButtonDriverActivity2);
        logoutButton.setOnClickListener((View v) -> {
            FirebaseAuth.getInstance().signOut();  // Sign out the user from FireBase
            // Show a confirmation toast message
            Toast.makeText(DriverActivity2.this, "Logged out successfully", Toast.LENGTH_SHORT).show();

            // Redirect to Splash screen and clear back stack
            Intent intent = new Intent(DriverActivity2.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();

        });

        Button backButton = findViewById(R.id.backButtonDriver2);
        // Redirect the user back to DriverActivity1 to create new Ride Offers when
        // they click on the back button.
        backButton.setOnClickListener((View v) -> {
            Intent i = new Intent(this, DriverActivity1.class);
            startActivity(i);
        });

        Button acceptedRideRequest = findViewById(R.id.button8);
        acceptedRideRequest.setOnClickListener((View v) -> {
            Intent i = new Intent(this, ViewAcceptedRideRequests.class);
            startActivity(i);
        });

        recyclerView = findViewById(R.id.recyclerViewRequests);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        rideRequests = new ArrayList<>();
        adapter = new RideRequestAdapter(rideRequests, "driver", new RideRequestAdapter.OnRideRequestClickListener() {
            @Override
            public void onEditClick(RideRequest request) {}

            @Override
            public void onDeleteClick(RideRequest request) {}

            @Override
            public void onAcceptClick(RideRequest request) {
                Toast.makeText(DriverActivity2.this, "Ride request accepted!", Toast.LENGTH_SHORT).show();
                DatabaseReference acceptedRef = FirebaseDatabase.getInstance().getReference("AcceptedRideRequests");
                DatabaseReference requestRef = FirebaseDatabase.getInstance().getReference("RideRequests").child(request.id);

                String driverEmail = FirebaseAuth.getInstance().getCurrentUser().getEmail();
                // accepted ride requests are to include the same fields as the ride request
                // card but with two additional fields. One being the driver who acceptec the
                // ride request and the other being the cost of the ride request.
                // Cost of the ride request is shown below.
                int cost = (int)(request.distance * 0.5);

                AcceptedRideRequest accepted = new AcceptedRideRequest(
                        request.id,
                        request.startPoint,
                        request.destination,
                        request.distance,
                        request.availabilityTime,
                        request.riderEmail,
                        driverEmail,
                        cost
                );

                acceptedRef.child(request.id).setValue(accepted);
                requestRef.removeValue();
            }
        });

        recyclerView.setAdapter(adapter);
        // Gather reference of Firebase "RideRequests" node from the database
        dbRef = FirebaseDatabase.getInstance().getReference("RideRequests");

        loadRideRequests();
    } //onCreate

    /**
     * Private helper function used to loadRideRequests that can be accepted
     * by drivers if they want too.*/
    private void loadRideRequests() {
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                rideRequests.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    RideRequest request = snap.getValue(RideRequest.class);
                    rideRequests.add(request);
                }
                //Sort unaccepted ride requests by availability date and distance
                Collections.sort(rideRequests, (a, b) -> {
                    if (a.availabilityTime != b.availabilityTime) {
                        return Long.compare(a.availabilityTime, b.availabilityTime); // Earlier availability first
                    } else {
                        return Double.compare(a.distance, b.distance); // Smaller distance second
                    }
                });


                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }
}