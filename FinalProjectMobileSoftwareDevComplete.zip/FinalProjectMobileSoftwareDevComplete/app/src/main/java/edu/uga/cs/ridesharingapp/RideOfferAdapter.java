package edu.uga.cs.ridesharingapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * The purpose of this class is to internally load the unaccepted and recently
 * crated ride offers from drivers, and to be displayed to riders to either accept
 * or reject them.*/
public class RideOfferAdapter extends RecyclerView.Adapter<RideOfferAdapter.ViewHolder> {
    /*private List<RideOffer> rideOfferList;

    public RideOfferAdapter(List<RideOffer> rideOfferList) {
        this.rideOfferList = rideOfferList;
    }


    @Override
    public RideViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.ride_offer_item, parent, false);
        return new RideViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RideViewHolder holder, int position) {
        RideOffer offer = rideOfferList.get(position);
        holder.dateTime.setText("Date/Time: " + offer.getDateTime());
        holder.startPoint.setText("Start: " + offer.getStartPoint());
        holder.destination.setText("Destination: " + offer.getDestination());
        holder.distance.setText("Distance: " + offer.getDistance() + " km");
    }

    @Override
    public int getItemCount() {
        return rideOfferList.size();
    }

    static class RideViewHolder extends RecyclerView.ViewHolder {
        TextView dateTime, startPoint, destination, distance;

        RideViewHolder(View itemView) {
            super(itemView);
            dateTime = itemView.findViewById(R.id.textViewDateTime);
            startPoint = itemView.findViewById(R.id.textViewStartPoint);
            destination = itemView.findViewById(R.id.textViewDestination);
            distance = itemView.findViewById(R.id.textViewDistance);
        }
    } */
    /* private List<RideOffer> rideOffers;
    private Context context;
    private DatabaseReference dbRef;

    public RideOfferAdapter(List<RideOffer> rideOffers, Context context) {
        this.rideOffers = rideOffers;
        this.context = context;
        dbRef = FirebaseDatabase.getInstance().getReference("RideOffers");
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textStart, textDest, textDistance, textTime;
        Button buttonEdit, buttonDelete;

        public ViewHolder(View itemView) {
            super(itemView);
            textStart = itemView.findViewById(R.id.textStart);
            textDest = itemView.findViewById(R.id.textDest);
            textDistance = itemView.findViewById(R.id.textDistance);
            textTime = itemView.findViewById(R.id.textTime);
            buttonEdit = itemView.findViewById(R.id.buttonEdit);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }

    @NonNull
    @Override
    public RideOfferAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.ride_offer_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RideOfferAdapter.ViewHolder holder, int position) {
        RideOffer offer = rideOffers.get(position);
        holder.textStart.setText("Start: " + offer.startPoint);
        holder.textDest.setText("Dest: " + offer.destination);
        holder.textDistance.setText("Distance: " + offer.distance + " mi");
        holder.textTime.setText("Time: " + new java.util.Date(offer.timestamp).toString());

        holder.buttonDelete.setOnClickListener(v -> {
            dbRef.child(offer.id).removeValue();
            rideOffers.remove(position);
            notifyItemRemoved(position);
        });

        holder.buttonEdit.setOnClickListener(v -> {
            if (context instanceof DriverActivity1) {
                ((DriverActivity1) context).populateFormForEdit(offer);
            }
        });
    }

    @Override
    public int getItemCount() {
        return rideOffers.size();
    } */
    private List<RideOffer> rideOfferList;
    private boolean isRider;
    private OnRideOfferClickListener listener;

    public interface OnRideOfferClickListener {
        void onEditClick(RideOffer rideOffer);
        void onDeleteClick(RideOffer rideOffer);
        void onAcceptClick(RideOffer rideOffer); // 👈 new listener
    }
    /**
     * This is the RideOfferAdapter constructor that will be used to create an instance
     * of this class outside of this class.
     * @param rideOfferList is the list of available ride offers.
     * @param isRider dictates whether the current logged in user trying to use this
     * class is either a rider or not. If they are a rider, then they can only view and
     * accept ride offers. If they are not a rider, then they can edit, delete, or create
     * new ride offers.
     * @param listener which is the reference to the radio button of being either a rider
     * or driver.*/
    public RideOfferAdapter(List<RideOffer> rideOfferList, boolean isRider, OnRideOfferClickListener listener) {
        this.rideOfferList = rideOfferList;
        this.isRider = isRider;
        this.listener = listener;
    }
    /**
     * Inner class used to grab references to UI elements from the correct
     * layout file and access them when needed*/
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textStart, textDestination, textDistance, textDate;
        TextView textAvailability;
        Button buttonEdit, buttonDelete, buttonAccept;
        TextView textDriverEmail;

        public ViewHolder(View itemView) {
            super(itemView);
            textStart = itemView.findViewById(R.id.textStartReq);
            textDestination = itemView.findViewById(R.id.textDestReq);
            textDistance = itemView.findViewById(R.id.textDistReq);
            textDate = itemView.findViewById(R.id.textTimeReq);
            textAvailability = itemView.findViewById(R.id.textAvailability);
            buttonEdit = itemView.findViewById(R.id.buttonEditReq);
            buttonDelete = itemView.findViewById(R.id.buttonDeleteReq);
            buttonAccept = itemView.findViewById(R.id.buttonAcceptReq);
            textDriverEmail = itemView.findViewById(R.id.textDriverEmail);
        }

        public void bind(RideOffer rideOffer) {
            textStart.setText("From: " + rideOffer.startPoint);
            textDestination.setText("To: " + rideOffer.destination);
            textDistance.setText("Distance: " + rideOffer.distance + " miles");
            textDate.setText("Date: " + new java.util.Date(rideOffer.timestamp).toString());
            String availability = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm").format(new java.util.Date(rideOffer.availabilityTime));
            textAvailability.setText("Available at: " + availability);
            textDriverEmail.setText("Driver: " + rideOffer.driverEmail);
            // Hide the edit and delete buttons for riders when seeing ride offers to accept
            // from otherwise hide the accept button and show both the edit and delete buttons for
            // drivers
            if (isRider) {
                buttonEdit.setVisibility(View.GONE);
                buttonDelete.setVisibility(View.GONE);
                buttonAccept.setVisibility(View.VISIBLE);

                buttonAccept.setOnClickListener(v -> listener.onAcceptClick(rideOffer));
            } else {
                buttonEdit.setVisibility(View.VISIBLE);
                buttonDelete.setVisibility(View.VISIBLE);
                buttonAccept.setVisibility(View.GONE);

                buttonEdit.setOnClickListener(v -> listener.onEditClick(rideOffer));
                buttonDelete.setOnClickListener(v -> listener.onDeleteClick(rideOffer));
            }
        }
    }

    @NonNull
    @Override
    public RideOfferAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.ride_offer_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RideOfferAdapter.ViewHolder holder, int position) {
        holder.bind(rideOfferList.get(position));
    }

    @Override
    public int getItemCount() {
        return rideOfferList.size();
    }
}
