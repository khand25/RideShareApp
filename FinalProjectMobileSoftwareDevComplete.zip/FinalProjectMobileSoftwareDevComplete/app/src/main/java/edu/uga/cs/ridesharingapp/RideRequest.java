package edu.uga.cs.ridesharingapp;
/**
 * Model class used to structure RideRequests.*/
public class RideRequest {
    public String id;
    public String startPoint;
    public String destination;
    public double distance;
    public long timestamp;
    public long availabilityTime;
    public String riderEmail;

    /**
     * The required default constructor for FireBase purposes*/
    public RideRequest() {}  // Needed for Firebase
    /**
     * Main constructor used to create an RideRequest instance outside of this class
     * to be used as cards on the display recycler views of available ride requests
     * to choose from.
     * @param id, which is the id of ride request
     * @param startPoint which is the starting point of pickup the rider is requesting
     * @param destination which is the ending point the rider is requesting to be driven to.
     * @param distance which is the total distance of the ride request
     * @param timestamp which is the date in which the ride request is created
     * @param availabilityTime which is the time that the rider is available to
     * offer a specific ride to riders
     * @param riderEmail which is the email of the rider requesting a ride */
    public RideRequest(String id, String startPoint, String destination, double distance, long timestamp, long availabilityTime, String riderEmail) {
        this.id = id;
        this.startPoint = startPoint;
        this.destination = destination;
        this.distance = distance;
        this.timestamp = timestamp;
        this.availabilityTime = availabilityTime;
        this.riderEmail = riderEmail;
    }

}
