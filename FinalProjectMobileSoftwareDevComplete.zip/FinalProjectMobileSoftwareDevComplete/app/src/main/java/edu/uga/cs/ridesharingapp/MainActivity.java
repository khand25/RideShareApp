package edu.uga.cs.ridesharingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * This is the main class responsible to displaying the splash screen/instructions
 * page to the user whenever the user initially launches the ride share app.*/
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // Get a reference by the id of the UI login in button programitcally
        Button loginButton = findViewById(R.id.button2);
        // set up event listener so that when the user clicks on the login
        // button, transistion to the login activity
        loginButton.setOnClickListener((View v) -> {
            Intent i = new Intent(this,LoginPage.class);
            startActivity(i);
        });
        //Set up an event listener so that whenever the user decides to click on
        // the register button, they will be transitioned to the register
        // activity
        Button registerButton = findViewById(R.id.button3);
        registerButton.setOnClickListener((View v) -> {
            Intent i = new Intent(this, RegisterActivity.class);
            startActivity(i);
        });

        // Used to handle saving the current state of the app, whenever the
        // user decides to change the orientation of the app or switch to another
        // app in the middle of execution
        if (savedInstanceState != null) {
            TextView textView1 = findViewById(R.id.textView1);
            TextView textView2 = findViewById(R.id.textView2);

            textView1.setText(savedInstanceState.getString("textView1Text", ""));
            textView2.setText(savedInstanceState.getString("textView2Text", ""));
        }

    } //onCreate

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        TextView textView1 = findViewById(R.id.textView1);
        TextView textView2 = findViewById(R.id.textView2);

        outState.putString("textView1Text", textView1.getText().toString());
        outState.putString("textView2Text", textView2.getText().toString());
    }

}