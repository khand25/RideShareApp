package edu.uga.cs.ridesharingapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * This class will be used to internally display the list of accepted ride requests
 * as an adapter like object to be used in the overall recycler views.*/
public class AcceptedRideRequestAdapter extends RecyclerView.Adapter<AcceptedRideRequestAdapter.ViewHolder> {

    private List<AcceptedRideRequest> acceptedList;
    private Context context;
    /**
     * Required constructor used to create an instance of this class outside of
     * this class.
     * @param context which represents the context object
     * @param list which represents the list of accepted ride requests either an rider
     * or driver can choose to confirm*/
    public AcceptedRideRequestAdapter(Context context, List<AcceptedRideRequest> list) {
        this.acceptedList = list;
        this.context = context;
    }
    /**
     * Inner class used to grab references to UI elements from the correct
     * layout file and access them when needed*/
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textStart, textDestination, textAvailabilityTime, textRiderEmail, textDriverEmail, textDistance, textCost;
        Button confirmButton;

        public ViewHolder(View view) {
            super(view);
            textStart = view.findViewById(R.id.textStart);
            textDestination = view.findViewById(R.id.textDestination);
            textAvailabilityTime = view.findViewById(R.id.textAvailabilityTime);
            textRiderEmail = view.findViewById(R.id.textRiderEmail);
            textDriverEmail = view.findViewById(R.id.textDriverEmail);
            textDistance = view.findViewById(R.id.textDistance);
            textCost = view.findViewById(R.id.textCost);
            confirmButton = itemView.findViewById(R.id.button10);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // inflate the appropriate layout resource file for accepting a ride request
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.accepted_ride_request_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        AcceptedRideRequest req = acceptedList.get(position);
        holder.textStart.setText("Start: " + req.start);
        holder.textDestination.setText("Destination: " + req.destination);
        holder.textAvailabilityTime.setText("Available: " + new java.util.Date(req.availabilityTime).toString());
        holder.textRiderEmail.setText("Rider: " + req.riderEmail);
        holder.textDriverEmail.setText("Driver: " + req.driverEmail);
        holder.textDistance.setText("Distance: " + req.distance + " miles");
        holder.textCost.setText("Cost in points: " + req.cost);

        // Confirm Ride Button
        //holder.confirmButton.setOnClickListener(v -> {
            //if (context instanceof ViewAcceptedRideRequests) {
                //((ViewAcceptedRideRequests) context).handleRideRequestConfirmation(req);
           // }
       // });
        //holder.confirmButton.setOnClickListener(v -> {
            //listener.onConfirmRide(req);
       // });

        // Confirm Ride Button logic
        holder.confirmButton.setOnClickListener(v -> {
            if (context instanceof ViewAcceptedRideRequests) {
                ((ViewAcceptedRideRequests) context).handleRideRequestConfirmation(req);
            }
        });
    }

    @Override
    public int getItemCount() {
        return acceptedList.size();
    }
}
