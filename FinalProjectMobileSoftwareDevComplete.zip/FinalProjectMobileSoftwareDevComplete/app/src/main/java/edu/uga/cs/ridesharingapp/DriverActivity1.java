package edu.uga.cs.ridesharingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * This class will be responsible for displaying the first available page to driver
 * users. This screen will allow users to create,edit, update, or delete unaccepted
 * ride offers as a driver.*/

public class DriverActivity1 extends AppCompatActivity {

    private EditText startInput, destInput, distInput;
    private EditText availabilityInput;
    private Button submitBtn;
    private RecyclerView recyclerView;
    private List<RideOffer> rideOffers;
    private RideOfferAdapter adapter;
    private DatabaseReference dbRef;
    private String editOfferId = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_driver1);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button viewRideRequests = findViewById(R.id.viewRideRequests);

        viewRideRequests.setOnClickListener((View v) -> {
            // go to the viewRideRequests screen when someone clicks on the button
            Intent i = new Intent(this, DriverActivity2.class);
            startActivity(i);
        });
        Button logoutButton = findViewById(R.id.logoutButtonDriverPage1);
        logoutButton.setOnClickListener((View v) -> {
            FirebaseAuth.getInstance().signOut();  // Sign out the user from FireBase
            // Show a confirmation toast message
            Toast.makeText(DriverActivity1.this, "Logged out successfully", Toast.LENGTH_SHORT).show();

            // Redirect to Splash screen and clear back stack
            Intent intent = new Intent(DriverActivity1.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();

        });
        // Allow user to transition to the screen to see accepted ride offers when
        // they click on the acceptedRideOffers button
        Button acceptedRideOffers = findViewById(R.id.ontoAcceptedRideOffersDriver1);
        acceptedRideOffers.setOnClickListener((View v) -> {
            Intent i = new Intent(this, ViewAcceptedRideOffers.class);
            startActivity(i);
        });

        startInput = findViewById(R.id.editTextStart);
        destInput = findViewById(R.id.editTextDestination);
        distInput = findViewById(R.id.editTextDistance);
        availabilityInput = findViewById(R.id.editTextAvailability);
        submitBtn = findViewById(R.id.buttonSubmitRequest);
        recyclerView = findViewById(R.id.recyclerViewRequests);

        rideOffers = new ArrayList<>();
        //adapter = new RideOfferAdapter(rideOffers, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RideOfferAdapter(rideOffers, false, new RideOfferAdapter.OnRideOfferClickListener() {
        //RideOfferAdapter adapter = new RideOfferAdapter(rideOffers, false, new RideOfferAdapter.OnRideOfferClickListener() {
            @Override
            public void onEditClick(RideOffer rideOffer) {
                showEditDialog(rideOffer);
            }

            @Override
            public void onDeleteClick(RideOffer rideOffer) {
                deleteRideOffer(rideOffer);
            }

            @Override
            public void onAcceptClick(RideOffer rideOffer) {
                // Should never be triggered in DriverActivity
            }
        });
        recyclerView.setAdapter(adapter);
        // gather the "RideOffer" node from Firebase
        dbRef = FirebaseDatabase.getInstance().getReference("RideOffers");

        // save instance state code
        // Used to handle saving the current state of the app, whenever the
        // user decides to change the orientation of the app or switch to another
        // app in the middle of execution
        if (savedInstanceState != null) {
            ArrayList<RideOffer> restoredOffers = (ArrayList<RideOffer>) savedInstanceState.getSerializable("rideOffers");
            if (restoredOffers != null) {
                rideOffers.clear();
                rideOffers.addAll(restoredOffers);
                adapter.notifyDataSetChanged();
            }

            startInput.setText(savedInstanceState.getString("startInput"));
            destInput.setText(savedInstanceState.getString("destInput"));
            distInput.setText(savedInstanceState.getString("distInput"));
            availabilityInput.setText(savedInstanceState.getString("availabilityInput"));
            editOfferId = savedInstanceState.getString("editOfferId");

            if (editOfferId != null) {
                submitBtn.setText("Update Ride Offer");
            }
        }

        // Perform appropriate RideOffer card view creations when the user clicks on
        // the submit button
        submitBtn.setOnClickListener(v -> {
            String start = startInput.getText().toString().trim();
            String dest = destInput.getText().toString().trim();
            String distStr = distInput.getText().toString().trim();
            String availStr = availabilityInput.getText().toString().trim();
            long availTime;
            // if the user decides to skip any of the required edit textboxes
            // to create a new ride offer, they will be prompted with an Toast message warning them
            if (start.isEmpty() || dest.isEmpty() || distStr.isEmpty() || availStr.isEmpty()) {
                Toast.makeText(this, "Fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            double distance = Double.parseDouble(distStr);
            long timestamp = System.currentTimeMillis();
            try {
                availTime = new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(availStr).getTime();
            } catch (ParseException e) {
                Toast.makeText(this, "Invalid date/time format", Toast.LENGTH_SHORT).show();
                return;
            }

            //Store the newly created ride offer into the Firebase database
            if (editOfferId == null) {
                String id = dbRef.push().getKey();
                String driverEmail = FirebaseAuth.getInstance().getCurrentUser().getEmail();
                int cost = 0; // unaccepted ride = no cost yet
                String acceptedBy = null;
                RideOffer offer = new RideOffer(id, start, dest, distance, timestamp, availTime, driverEmail,cost,acceptedBy);
                //RideOffer offer = new RideOffer(id, start, dest, distance, timestamp,availTime);
                dbRef.child(id).setValue(offer);
            } else {
                String driverEmail = FirebaseAuth.getInstance().getCurrentUser().getEmail();
                int cost = 0; // unaccepted ride = no cost yet
                String acceptedBy = null;
                RideOffer offer = new RideOffer(editOfferId, start, dest, distance, timestamp, availTime,driverEmail,cost,acceptedBy);
                dbRef.child(editOfferId).setValue(offer);
                editOfferId = null;
                submitBtn.setText("Submit Ride Offer");
            }

            startInput.setText("");
            destInput.setText("");
            distInput.setText("");
            availabilityInput.setText("");
        });

        loadRideOffers();
    }
    /**
     * private helper method used to load current ride offers to the screen as
     * a card part of an overall recycler view*/
    private void loadRideOffers() {
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                rideOffers.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    RideOffer offer = snap.getValue(RideOffer.class);
                    rideOffers.add(offer);
                }
                /*
                Collections.sort(rideOffers, (a, b) -> {
                    if (a.distance != b.distance) {
                        return Double.compare(a.distance, b.distance);
                    } else {
                        return Long.compare(b.timestamp, a.timestamp);
                    }
                }); */

                // Handles sorting of ride offers card views with earliest
                // availability time to latest. If two availability times are the same,
                // then shortest distance (ascending order) is done.
                Collections.sort(rideOffers, (a, b) -> {
                    if (a.availabilityTime != b.availabilityTime) {
                        return Long.compare(a.availabilityTime, b.availabilityTime); // Earlier availability first
                    } else {
                        return Double.compare(a.distance, b.distance); // Smaller distance second
                    }
                });

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }
    /**
     * Function that will be used to populate the dialog edit box when
     * a user decides to update an existing unaccepted ride offer.
     * @param offer which is the current ride offer that the user wants to
     * update.*/

    public void populateFormForEdit(RideOffer offer) {
        startInput.setText(offer.startPoint);
        destInput.setText(offer.destination);
        distInput.setText(String.valueOf(offer.distance));
        editOfferId = offer.id;
        submitBtn.setText("Update Ride Offer");
    }
    /**
     * Function that will be used to delete a ride offer both from the screen
     * and from Firebase
     * @param rideOffer which is the current ride offer that the user wants to
     * delete.*/
    private void deleteRideOffer(RideOffer rideOffer) {
        DatabaseReference rideRef = FirebaseDatabase.getInstance().getReference("RideOffers").child(rideOffer.id);
        rideRef.removeValue().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(this, "Ride offer deleted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to delete ride offer", Toast.LENGTH_SHORT).show();
            }
        });
    }
    /**
     * Function that will be used to display the dialog edit box when
     * a user decides to update an existing unaccepted ride offer.
     * @param rideOffer which is the current ride offer that the user wants to
     * update.*/
    private void showEditDialog(RideOffer rideOffer) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Ride Offer");
        // Inflate the dialog_edit_offer.xml layout file
        View viewInflated = LayoutInflater.from(this).inflate(R.layout.dialog_edit_offer, (ViewGroup) findViewById(android.R.id.content), false);

        final EditText inputStart = viewInflated.findViewById(R.id.editStartPoint);
        final EditText inputDestination = viewInflated.findViewById(R.id.editDestination);
        final EditText inputDistance = viewInflated.findViewById(R.id.editDistance);
        final EditText editAvailability = viewInflated.findViewById(R.id.editTextAvailability); // <-- new
        inputStart.setText(rideOffer.startPoint);
        inputDestination.setText(rideOffer.destination);
        inputDistance.setText(String.valueOf(rideOffer.distance));
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
        String availabilityStr = sdf.format(new Date(rideOffer.availabilityTime));
        editAvailability.setText(availabilityStr);

        builder.setView(viewInflated);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String updatedStart = inputStart.getText().toString().trim();
            String updatedDest = inputDestination.getText().toString().trim();
            double updatedDist;
            String newAvailabilityStr = editAvailability.getText().toString().trim();

            try {
                updatedDist = Double.parseDouble(inputDistance.getText().toString().trim());
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid distance input.", Toast.LENGTH_SHORT).show();
                return;
            }

            long newAvailabilityTime;
            try {
                newAvailabilityTime = sdf.parse(newAvailabilityStr).getTime();
            } catch (ParseException e) {
                Toast.makeText(this, "Invalid availability format", Toast.LENGTH_SHORT).show();
                return;
            }

            DatabaseReference rideRef = FirebaseDatabase.getInstance().getReference("RideOffers").child(rideOffer.id);
            rideRef.child("startPoint").setValue(updatedStart);
            rideRef.child("destination").setValue(updatedDest);
            rideRef.child("distance").setValue(updatedDist);
            rideRef.child("availabilityTime").setValue(newAvailabilityTime);
            Toast.makeText(this, "Ride offer updated.", Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    // save instance code
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("startInput", startInput.getText().toString());
        outState.putString("destInput", destInput.getText().toString());
        outState.putString("distInput", distInput.getText().toString());
        outState.putString("availabilityInput", availabilityInput.getText().toString());
        outState.putString("editOfferId", editOfferId);
        outState.putSerializable("rideOffers", new ArrayList<>(rideOffers));
    }

}