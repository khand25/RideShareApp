package edu.uga.cs.ridesharingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/**
 * This class will be used to load and display already accepted ride offers
 * by riders to the user as either an logged in driver or rider*/
public class ViewAcceptedRideOffers extends AppCompatActivity {

    private RecyclerView recyclerView;
    private AcceptedRideOfferAdapter adapter;
    private List<RideOffer> acceptedRideOffers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_view_accepted_ride_offers);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button logoutButton = findViewById(R.id.button7);
        logoutButton.setOnClickListener((View v) -> {
            FirebaseAuth.getInstance().signOut();  // Sign out the user from FireBase
            // Show a confirmation toast message
            Toast.makeText(ViewAcceptedRideOffers.this, "Logged out successfully", Toast.LENGTH_SHORT).show();

            // Redirect to Splash screen and clear back stack
            Intent intent = new Intent(ViewAcceptedRideOffers.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();

        });
        recyclerView = findViewById(R.id.acceptedRideOffersRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        acceptedRideOffers = new ArrayList<>();
        adapter = new AcceptedRideOfferAdapter(acceptedRideOffers,this::handleRideConfirmation);
        recyclerView.setAdapter(adapter);

        loadAcceptedRidesFromFirebase();

    } //onCreate

    /**
     * This function will be used to extract the accepted ride offers from Firebase
     * and be used to display on the activity_view_accepted_ride_offers.xml file*/
    private void loadAcceptedRidesFromFirebase() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("AcceptedRideOffers");
        //grab the reference to the AcceptedRideOffers node from Firebase
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange( DataSnapshot snapshot) {
                acceptedRideOffers.clear();
                for (DataSnapshot rideSnapshot : snapshot.getChildren()) {
                    RideOffer ride = rideSnapshot.getValue(RideOffer.class);
                    if (ride != null) {
                        acceptedRideOffers.add(ride);
                    }
                }

                // Optional: sort by availability time, or cost
                //Collections.sort(acceptedRideOffers, (a, b) -> Long.compare(a.availabilityTime, b.availabilityTime));

                acceptedRideOffers.sort((a, b) -> {
                    int byAvailability = Long.compare(a.availabilityTime, b.availabilityTime);
                    if (byAvailability != 0) return byAvailability;
                    return Double.compare(a.distance, b.distance);
                });

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(ViewAcceptedRideOffers.this, "Failed to load accepted rides.", Toast.LENGTH_SHORT).show();
            }
        });
    }
    /**
     * Function that will be used to delete and do the proper balance changes
     * to both the rider and driver balances in the database when either user
     * clicks on the confirm button on a accepted ride offer.
     * @param ride which is the current ride offer the user is trying to confirm*/
    private void handleRideConfirmation(RideOffer ride) {
        DatabaseReference acceptedRef = FirebaseDatabase.getInstance().getReference("AcceptedRideOffers").child(ride.id);
        //int cost = (int) ride.distance / 2;
       //long cost = Math.round(ride.distance / 2.0);
        //Formula to calculate cost of the ride offer
        long cost = (int)(ride.distance / 2.0);
        //long cost = ride.cost;

        DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("Users");

        // Get rider data first
        userRef.orderByChild("email").equalTo(ride.acceptedByEmail).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot riderSnapshot) {
                if (!riderSnapshot.exists()) {
                    Toast.makeText(ViewAcceptedRideOffers.this, "Rider not found.", Toast.LENGTH_SHORT).show();
                    return;
                }

                DataSnapshot riderData = riderSnapshot.getChildren().iterator().next();
                Long riderBalance = riderData.child("riderBalance").getValue(Long.class);
                if (riderBalance == null) riderBalance = 0L;
                //Must block the user from confirming a ride offer if they don't have
                // enough balance in their rider balance
                if (riderBalance < cost) {
                    Toast.makeText(ViewAcceptedRideOffers.this,
                            "Cannot confirm a ride took place as your rider balance is too low.",
                            Toast.LENGTH_LONG).show();
                    return;
                }

                // Update rider balance
                riderData.getRef().child("riderBalance").setValue(riderBalance - cost);

                // Now get and update the driver
                userRef.orderByChild("email").equalTo(ride.driverEmail).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot driverSnapshot) {
                        if (!driverSnapshot.exists()) {
                            Toast.makeText(ViewAcceptedRideOffers.this, "Driver not found.", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        DataSnapshot driverData = driverSnapshot.getChildren().iterator().next();
                        Long driverBalance = driverData.child("driverBalance").getValue(Long.class);
                        if (driverBalance == null) driverBalance = 0L;

                        driverData.getRef().child("driverBalance").setValue(driverBalance + cost);

                        // Remove the accepted ride and properly increment the aossicated driver balance
                        // decrement the rider balance by the cost
                        acceptedRef.removeValue();
                        Toast.makeText(ViewAcceptedRideOffers.this,
                                "Ride confirmed. Balances updated!", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        Toast.makeText(ViewAcceptedRideOffers.this,
                                "Error updating driver balance", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(ViewAcceptedRideOffers.this,
                        "Error accessing rider data", Toast.LENGTH_SHORT).show();
            }
        });
    }
}