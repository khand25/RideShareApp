package edu.uga.cs.ridesharingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/**
 * This class will be used to load and display already accepted ride requests
 * by drivers to the user as either an logged in driver or rider*/
public class ViewAcceptedRideRequests extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<AcceptedRideRequest> acceptedList;
    private AcceptedRideRequestAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_view_accepted_ride_requests);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button backButton = findViewById(R.id.backButtonAcceptedRideRequests);
        backButton.setOnClickListener((View v) -> {
            FirebaseAuth.getInstance().signOut();  // Sign out the user from FireBase
            // Show a confirmation toast message
            Toast.makeText(ViewAcceptedRideRequests.this, "Logged out successfully", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(this, MainActivity.class);
            startActivity(i);
        });

        recyclerView = findViewById(R.id.recyclerViewAcceptedRideRequests);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        acceptedList = new ArrayList<>();
        adapter = new AcceptedRideRequestAdapter(this,acceptedList);
        recyclerView.setAdapter(adapter);

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("AcceptedRideRequests");

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange( DataSnapshot snapshot) {
                acceptedList.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    AcceptedRideRequest request = snap.getValue(AcceptedRideRequest.class);
                    acceptedList.add(request);
                }

                // Sort by availability time, then distance
                Collections.sort(acceptedList, (a, b) -> {
                    if (a.availabilityTime != b.availabilityTime) {
                        return Long.compare(a.availabilityTime, b.availabilityTime);
                    } else {
                        return Double.compare(a.distance, b.distance);
                    }
                });

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError error) {}
        });
    } //onCreate
    /**
     * Function that will be used to delete and do the proper balance changes
     * to both the rider and driver balances in the database when either user
     * clicks on the confirm button on a accepted ride offer.
     * @param ride which is the current accepted ride request the user wants to
     * confirm*/
    public void handleRideRequestConfirmation(AcceptedRideRequest ride) {
        DatabaseReference acceptedRef = FirebaseDatabase.getInstance()
                .getReference("AcceptedRideRequests").child(ride.id);
        // cost formula for the ride request
        int cost = (int) (ride.distance / 2);

        DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("Users");

        // Step 1: Check Rider Balance
        userRef.orderByChild("email").equalTo(ride.riderEmail)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot riderSnapshot) {
                        if (!riderSnapshot.exists()) {
                            Toast.makeText(ViewAcceptedRideRequests.this, "Rider not found.", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        DataSnapshot riderData = riderSnapshot.getChildren().iterator().next();
                        Long riderBalance = riderData.child("riderBalance").getValue(Long.class);
                        if (riderBalance == null) riderBalance = 0L;
                        //Must block the user from confirming a ride request if they don't have
                        // enough balance in their rider balance
                        if (riderBalance < cost) {
                            Toast.makeText(ViewAcceptedRideRequests.this,
                                    "Cannot confirm ride — rider balance too low.",
                                    Toast.LENGTH_LONG).show();
                            return;
                        }

                        // Step 2: Deduct from Rider
                        riderData.getRef().child("riderBalance").setValue(riderBalance - cost);

                        // Step 3: Update Driver
                        userRef.orderByChild("email").equalTo(ride.driverEmail)
                                .addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(DataSnapshot driverSnapshot) {
                                        if (!driverSnapshot.exists()) {
                                            Toast.makeText(ViewAcceptedRideRequests.this, "Driver not found.", Toast.LENGTH_SHORT).show();
                                            return;
                                        }

                                        DataSnapshot driverData = driverSnapshot.getChildren().iterator().next();
                                        Long driverBalance = driverData.child("driverBalance").getValue(Long.class);
                                        if (driverBalance == null) driverBalance = 0L;

                                        driverData.getRef().child("driverBalance").setValue(driverBalance + cost);

                                        // Step 4: Remove ride request
                                        acceptedRef.removeValue();

                                        Toast.makeText(ViewAcceptedRideRequests.this,
                                                "Ride confirmed. Balances updated.",
                                                Toast.LENGTH_SHORT).show();
                                    }

                                    @Override
                                    public void onCancelled(DatabaseError error) {
                                        Toast.makeText(ViewAcceptedRideRequests.this,
                                                "Error updating driver balance.", Toast.LENGTH_SHORT).show();
                                    }
                                });
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        Toast.makeText(ViewAcceptedRideRequests.this,
                                "Error accessing rider data.", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}