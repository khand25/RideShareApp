package edu.uga.cs.ridesharingapp;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
/**
 * The purpose of this class is to internally load the unaccepted and recently
 * crated ride requests from riders, and to be displayed to drivers to either accept
 * or reject them.*/
public class RideRequestAdapter extends RecyclerView.Adapter<RideRequestAdapter.RequestViewHolder>{

    private List<RideRequest> requestList;
    private boolean isDriverView;
    private OnRideRequestClickListener listener;

    private String userRole;
    /**
     * This interface will be used to dictate the possible operations a user could
     * perform (if they are a rider, or driver) on a previously created ride request.*/
    public interface OnRideRequestClickListener {
        void onEditClick(RideRequest request);
        void onDeleteClick(RideRequest request);
        void onAcceptClick(RideRequest request);
    }
    /**
     * This is the RideRequestAdapter constructor that will be used to create an instance
     * of this class outside of this class.
     * @param requestList is the list of available ride requests.
     * @param userRole dictates whether the current logged in user trying to use this
     * class is either a rider or not. If they are a driver, then they can only view and
     * accept ride requests. If they are a rider, then they can edit, delete, or create
     * new ride requests.
     * @param listener which is the reference to the radio button of being either a rider
     * or driver.*/
    public RideRequestAdapter(List<RideRequest> requestList, String userRole, OnRideRequestClickListener listener) {
        this.requestList = requestList;
        //this.isDriverView = isDriverView;
        this.userRole = userRole;
        this.listener = listener;
    }


    @Override
    public RequestViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.ride_request_item, parent, false);
        return new RequestViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RequestViewHolder holder, int position) {
        RideRequest request = requestList.get(position);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());

        holder.textStart.setText("From: " + request.startPoint);
        holder.textDestination.setText("To: " + request.destination);
        holder.textDistance.setText("Distance: " + request.distance + " mi");
        holder.textAvailability.setText("Available Time: " + sdf.format(new Date(request.availabilityTime)));
        Log.d("RideRequestAdapter", "Binding request: " + request.riderEmail);
        holder.textEmail.setText("Requested by: " + request.riderEmail);
       // holder.textEmail.setText("Requested by: test@example.com"); // <- Also try this one line instead
        /*
        // Show/hide buttons based on user role
        holder.buttonEdit.setVisibility(isDriverView ? View.GONE : View.VISIBLE);
        holder.buttonDelete.setVisibility(isDriverView ? View.GONE : View.VISIBLE);
        holder.buttonAccept.setVisibility(isDriverView ? View.VISIBLE : View.GONE); */
        String currentUserEmail = FirebaseAuth.getInstance().getCurrentUser().getEmail();
        /*
// If the current user is the a driver (i.e., the driver)
        if (request.riderEmail.equals(currentUserEmail)) {
            holder.buttonEdit.setVisibility(View.VISIBLE);
            holder.buttonDelete.setVisibility(View.VISIBLE);
            holder.buttonAccept.setVisibility(View.GONE); // Riders shouldn't accept
            //holder.buttonEdit.setVisibility(View.GONE);
            //holder.buttonDelete.setVisibility(View.GONE);
            //holder.buttonAccept.setVisibility(View.VISIBLE);
        } else {
            holder.buttonEdit.setVisibility(View.GONE);
            holder.buttonDelete.setVisibility(View.GONE);
            holder.buttonAccept.setVisibility(View.VISIBLE); // Driver viewing this

            //holder.buttonEdit.setVisibility(View.VISIBLE);
           // holder.buttonDelete.setVisibility(View.VISIBLE);
           // holder.buttonAccept.setVisibility(View.GONE);
        } */

        // Button visibility based on user role
        if (userRole.equals("rider")) {
            // Riders can edit/delete all ride requests
            holder.buttonEdit.setVisibility(View.VISIBLE);
            holder.buttonDelete.setVisibility(View.VISIBLE);
            holder.buttonAccept.setVisibility(View.GONE);
        } else {
            // Drivers can only accept
            holder.buttonEdit.setVisibility(View.GONE);
            holder.buttonDelete.setVisibility(View.GONE);
            holder.buttonAccept.setVisibility(View.VISIBLE);
        }

        holder.buttonEdit.setOnClickListener(v -> listener.onEditClick(request));
        holder.buttonDelete.setOnClickListener(v -> listener.onDeleteClick(request));
        holder.buttonAccept.setOnClickListener(v -> listener.onAcceptClick(request));
    }

    @Override
    public int getItemCount() {
        return requestList.size();
    }
    /**
     * Inner class used to grab references to UI elements from the correct
     * layout file and access them when needed*/
    static class RequestViewHolder extends RecyclerView.ViewHolder {
        TextView textStart, textDestination, textDistance, textAvailability, textEmail;
        Button buttonEdit, buttonDelete, buttonAccept;

        RequestViewHolder(@NonNull View itemView) {
            super(itemView);
            textStart = itemView.findViewById(R.id.textStartReq);
            textDestination = itemView.findViewById(R.id.textDestReq);
            textDistance = itemView.findViewById(R.id.textDistReq);
            textAvailability = itemView.findViewById(R.id.textTimeReq);
            textEmail = itemView.findViewById(R.id.textEmail);
            buttonEdit = itemView.findViewById(R.id.buttonEditReq);
            buttonDelete = itemView.findViewById(R.id.buttonDeleteReq);
            buttonAccept = itemView.findViewById(R.id.buttonAcceptReq);
        }
    }
}
