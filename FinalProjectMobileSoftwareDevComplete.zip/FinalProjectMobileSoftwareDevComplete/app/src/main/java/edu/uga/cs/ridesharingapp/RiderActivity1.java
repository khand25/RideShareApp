package edu.uga.cs.ridesharingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/**
 * This class will be used to display the first page for logged in riders.
 * The first page shows the list of unaccepted ride offers to select and
 * accept from. */
public class RiderActivity1 extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RideOfferAdapter adapter;
    private List<RideOffer> rideOffers = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_rider1);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // transition to the RideActivity2 when the user clicks on the appropriate
        // button to initiate creating new ride requests.
        Button transistionToCreateRideRequest = findViewById(R.id.button5);
        transistionToCreateRideRequest.setOnClickListener((View v) -> {
            Intent i = new Intent(this, RiderActivity2.class);
            startActivity(i);
        });
        Button logoutButton = findViewById(R.id.logoutButtonRiderPage1);
        logoutButton.setOnClickListener((View v) -> {
            FirebaseAuth.getInstance().signOut();  // Sign out the user from FireBase
            // Show a confirmation toast message
            Toast.makeText(RiderActivity1.this, "Logged out successfully", Toast.LENGTH_SHORT).show();

            // Redirect to Splash screen and clear back stack
            Intent intent = new Intent(RiderActivity1.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();

        });
        //Transition the user to the screen to see already accepted ride
        // offers, when they click on the view accepeted ride offers button
        Button ontoAcceptedRideOffers = findViewById(R.id.button6);
        ontoAcceptedRideOffers.setOnClickListener((View v) -> {
            Intent i = new Intent(this, ViewAcceptedRideOffers.class);
            startActivity(i);
        });

        /*recyclerView = findViewById(R.id.recyclerViewRides);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        //adapter = new RideOfferAdapter(rideOffers,this);
        RideOfferAdapter adapter = new RideOfferAdapter(rideOffers, true, new RideOfferAdapter.OnRideOfferClickListener() {
            @Override
            public void onEditClick(RideOffer rideOffer) {
                // Should never be triggered in RiderActivity
            }

            @Override
            public void onDeleteClick(RideOffer rideOffer) {
                // Should never be triggered in RiderActivity
            }

            @Override
            public void onAcceptClick(RideOffer rideOffer) {
                // ✅ Accept logic — maybe save it under "AcceptedRides" in Firebase or open a confirmation screen
                Toast.makeText(RiderActivity1.this, "Ride Accepted:\n" + rideOffer.startPoint + " ➡ " + rideOffer.destination, Toast.LENGTH_SHORT).show();
            }
        });
        recyclerView.setAdapter(adapter); */
        recyclerView = findViewById(R.id.recyclerViewRides); // or whatever your RecyclerView ID is
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        rideOffers = new ArrayList<>();

        adapter = new RideOfferAdapter(rideOffers, true, new RideOfferAdapter.OnRideOfferClickListener() {
            @Override
            public void onEditClick(RideOffer rideOffer) {
                // Do nothing or show a message, riders can't edit
            }

            @Override
            public void onDeleteClick(RideOffer rideOffer) {
                // Do nothing or show a message, riders can't delete
            }
            

            @Override
            public void onAcceptClick(RideOffer rideOffer) {
                Toast.makeText(RiderActivity1.this, "Ride accepted!", Toast.LENGTH_SHORT).show();
                String currentUserEmail = FirebaseAuth.getInstance().getCurrentUser().getEmail();

                DatabaseReference acceptedRef = FirebaseDatabase.getInstance().getReference("AcceptedRideOffers");
                DatabaseReference originalRef = FirebaseDatabase.getInstance().getReference("RideOffers");
                // apply the formula to assing a cost to a ride offer that is being accepted
                // by a rider
                int cost = (int) (rideOffer.distance * 0.5);
                rideOffer.cost = cost;
                rideOffer.acceptedByEmail = currentUserEmail;

                acceptedRef.child(rideOffer.id).setValue(rideOffer)
                        .addOnSuccessListener(aVoid -> {
                            // Remove from RideOffers in Firebase
                            originalRef.child(rideOffer.id).removeValue()
                                    .addOnSuccessListener(v -> {
                                        // Now also remove from local list and update RecyclerView
                                        rideOffers.remove(rideOffer);
                                        adapter.notifyDataSetChanged();
                                        Toast.makeText(RiderActivity1.this, "Ride accepted and removed!", Toast.LENGTH_SHORT).show();
                                    });
                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(RiderActivity1.this, "Failed to accept ride.", Toast.LENGTH_SHORT).show();
                        });
            }

        });

        recyclerView.setAdapter(adapter);

        loadRideOffers();
    } //onCreate
    /**
     * * Function that will be used to load available nonaccepted ride
     * offers to the users as riders.*/
    private void loadRideOffers() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("RideOffers");

        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                rideOffers.clear();
                for (DataSnapshot rideSnapshot : snapshot.getChildren()) {
                    RideOffer ride = rideSnapshot.getValue(RideOffer.class);
                    if (ride != null) {
                        rideOffers.add(ride);
                    }
                }

                // Sort by distance ASC, then dateTime DESC
                /*rideOffers.sort((a, b) -> {
                    int distCompare = Double.compare(a.distance, b.distance);
                    if (distCompare != 0) return distCompare;

                    // You may want to use proper date parsing if you store as ISO 8601 format
                    return b..compareTo(a.timestamp); // Descending date/time
                }); */
                /*
                Collections.sort(rideOffers, (a, b) -> {
                    if (a.distance != b.distance) {
                        return Double.compare(a.distance, b.distance);
                    } else {
                        return Long.compare(b.timestamp, a.timestamp);
                    }
                }); */
                // Sort the unaccepted ride offers by availability time and shortest
                // to longest time
                Collections.sort(rideOffers, (a, b) -> {
                    if (a.availabilityTime != b.availabilityTime) {
                        return Long.compare(a.availabilityTime, b.availabilityTime); // Earlier availability first
                    } else {
                        return Double.compare(a.distance, b.distance); // Smaller distance second
                    }
                });

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(RiderActivity1.this, "Failed to load ride offers", Toast.LENGTH_SHORT).show();
            }
        });
    }
}