package edu.uga.cs.ridesharingapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import android.util.Patterns;

/**
 * RegisterActivity class will be responsible for displaying the register page
 * to the user for trying to create a new account into the database.*/
public class RegisterActivity extends AppCompatActivity {

    private static final String DEBUG_TAG = "RegisterActivity";
    private EditText editTextEmail, editTextPassword;
    private Button buttonRegister;
    private DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonRegister = findViewById(R.id.buttonRegister);

        // Used to handle saving the current state of the app, whenever the
        // user decides to change the orientation of the app or switch to another
        // app in the middle of execution
        if (savedInstanceState != null) {
            editTextEmail.setText(savedInstanceState.getString("email", ""));
            editTextPassword.setText(savedInstanceState.getString("password", ""));

            int selectedRole = savedInstanceState.getInt("selectedRole", -1);
            if (selectedRole != -1) {
                RadioButton selectedButton = findViewById(selectedRole);
                if (selectedButton != null) {
                    selectedButton.setChecked(true);
                }
            }
        }


        // Initialize Firebase Database reference
        databaseReference = FirebaseDatabase.getInstance().getReference("Users");

        // When the user clicks on the register button, execute the
        // registerUserImproved function
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUserImproved();
            }
        });
    } //onCreate
    /**
     * Function that will be used to initiate registering a user to the
     * Firebase realtime database.*/
    private void registerUser() {

        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        if (TextUtils.isEmpty(email)) {
            editTextEmail.setError("Email is required");
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editTextEmail.setError("Please enter a valid email");
            return;
        }

        if (password.length() < 6) {
            editTextPassword.setError("Password must be at least 6 characters");
            return;
        }

        if (TextUtils.isEmpty(password)) {
            editTextPassword.setError("Password is required");
            return;
        }
        /*
        // Create a unique ID for the user
        String userId = databaseReference.push().getKey();

        // Create a new User object
        User newUser = new User(email, hashPassword(password));

        if (userId != null) {
            // Now if someone registers as a new user, add it as new node under the
            // Users array in Firebase RealTimeDataBase as a new User node array JSON
            // element
            databaseReference.child(userId).setValue(newUser)
                    // When the adding of a user to the Firebase RealTimedatabase is sucessful
                    // proceed to show a popup toast message
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(RegisterActivity.this, "User registered successfully", Toast.LENGTH_SHORT).show();
                            // Navigate to LoginActivity or HomeActivity if you want
                            startActivity(new Intent(RegisterActivity.this, LoginPage.class));
                            finish();
                        } else {
                            Toast.makeText(RegisterActivity.this, "Failed to register user", Toast.LENGTH_SHORT).show();
                        }
                    });
        } */

        // Check if email already exists
        databaseReference.orderByChild("email").equalTo(email)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            // Email already in use
                            Toast.makeText(RegisterActivity.this, "Email already registered", Toast.LENGTH_SHORT).show();
                        } else {
                            // Email is unique — register the user
                            String userId = databaseReference.push().getKey();
                            Map<String, String> userData = new HashMap<>();
                            userData.put("email", email);
                            userData.put("password", hashPassword(password)); // optional encryption method

                            databaseReference.child(userId).setValue(userData)
                                    .addOnCompleteListener(task -> {
                                        if (task.isSuccessful()) {
                                            Toast.makeText(RegisterActivity.this, "Registration successful", Toast.LENGTH_SHORT).show();
                                            // Optionally go to login screen
                                            // Navigate to LoginActivity or HomeActivity if you want
                                            startActivity(new Intent(RegisterActivity.this, LoginPage.class));
                                            finish();
                                        } else {
                                            Toast.makeText(RegisterActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                        }

                    } //onDataChange


                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(RegisterActivity.this, "Database error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
    /**
     * Main helper function responsible for properly checking, gathering
     * and storing user entered email and password combination into the
     * User's node in Firebase.*/
    private void registerUserImproved() {
        // Gather the user entered email and passwords from the edit text fields.
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        // Error checking set of if statements where the user must enter a valid
        // email, and passwords with appropriate 6 or more character lengths.
        if (TextUtils.isEmpty(email)) {
            editTextEmail.setError("Email is required");
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editTextEmail.setError("Please enter a valid email");
            return;
        }

        if (TextUtils.isEmpty(password)) {
            editTextPassword.setError("Password is required");
            return;
        }

        if (password.length() < 6) {
            editTextPassword.setError("Password must be at least 6 characters");
            return;
        }

        FirebaseAuth mAuth = FirebaseAuth.getInstance();

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(RegisterActivity.this, task -> {
                    if (task.isSuccessful()) {
                        // Registration successful
                        FirebaseUser firebaseUser = mAuth.getCurrentUser();

                        //Store user info in Realtime Database
                        if (firebaseUser != null) {
                            String userId = firebaseUser.getUid();
                            DatabaseReference userRef = FirebaseDatabase.getInstance()
                                    .getReference("Users").child(userId);

                            // Only storing email for simplicity. You can add more fields.
                            Map<String, Object> userData = new HashMap<>();
                            // When a new user registers into the app, initialize both their
                            // unique rider and driver balances to 1000 as well as their
                            // selected email to the User's node
                            userData.put("email", email);
                            userData.put("riderBalance", 1000);
                            userData.put("driverBalance", 1000);
                            // Show appropriate toast messages s the user successfully
                            // registers into the app or not
                            userRef.setValue(userData)
                                    .addOnCompleteListener(dbTask -> {
                                        if (dbTask.isSuccessful()) {
                                            Toast.makeText(RegisterActivity.this,
                                                    "User registered successfully", Toast.LENGTH_SHORT).show();
                                            startActivity(new Intent(RegisterActivity.this, LoginPage.class));
                                            finish();
                                        } else {
                                            Toast.makeText(RegisterActivity.this,
                                                    "Failed to save user info", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                        }
                    } else {
                        Toast.makeText(RegisterActivity.this,
                                "Registration failed: " + task.getException().getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                });
    }



    /*** Hashing scheme function for manually hashing passwords for user's before
     * storing them into Firebase.
     * @param password which is represents the user entered password we wish
     * to hash
     * @return the hashed password to store into the database
     */
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();

            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }

            return hexString.toString();

            } catch (NoSuchAlgorithmException e) {
                throw new RuntimeException(e);
            }
        }
        // User model class
        private static class User {
            public String email;
            public String password;

            public User() {
            // Default constructor required for calls to DataSnapshot.getValue(User.class)
            }

            public User(String email, String password) {
                this.email = email;
                this.password = password;
            }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putString("email", editTextEmail.getText().toString());
        outState.putString("password", editTextPassword.getText().toString());

        // Save which radio button is selected
        int selectedId = ((RadioGroup) findViewById(R.id.radioButton2).getParent()).getCheckedRadioButtonId();
        outState.putInt("selectedRole", selectedId);
    }

} //RegisterActivity