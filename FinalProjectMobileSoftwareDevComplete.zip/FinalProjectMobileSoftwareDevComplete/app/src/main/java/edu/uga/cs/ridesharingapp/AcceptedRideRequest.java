package edu.uga.cs.ridesharingapp;

/**
 * Model class used to structure AcceptedRideRequests.*/
public class AcceptedRideRequest {

    public String id;
    public String start;
    public String destination;
    public double distance;
    public long availabilityTime;
    public String riderEmail;
    public String driverEmail;
    public int cost;
    /**
     * The required default constructor for FireBase purposes*/
    public AcceptedRideRequest() {} // Needed for Firebase
    /**
     * Main constructor used to create an RideRequest instance outside of this class
     * to be used as cards on the display recycler views of available ride requests
     * to choose from.
     * @param id, which is the id of ride request
     * @param start which is the starting point of pickup the rider is requesting
     * @param destination which is the ending point the rider is requesting to be driven to.
     * @param distance which is the total distance of the ride request
     * @param cost which is the total cost of the ride request
     * @param availabilityTime which is the time that the rider is available to
     * offer a specific ride to riders
     * @param riderEmail which is the email of the rider requesting a ride
     * @param driverEmail which is the email of the driver who had already accepted
     * the ride request to fulfill. */
    public AcceptedRideRequest(String id, String start, String destination, double distance, long availabilityTime, String riderEmail, String driverEmail, int cost) {
        this.id = id;
        this.start = start;
        this.destination = destination;
        this.distance = distance;
        this.availabilityTime = availabilityTime;
        this.riderEmail = riderEmail;
        this.driverEmail = driverEmail;
        this.cost = cost;
    }
}
