package edu.uga.cs.ridesharingapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * This class will be used to internally display the list of accepted ride offers
 * as an adapter like object to be used in the overall recycler views.*/
public class AcceptedRideOfferAdapter extends RecyclerView.Adapter<AcceptedRideOfferAdapter.ViewHolder>{

    private List<RideOffer> acceptedRideOffers;
    private OnConfirmRideListener listener;
    /**
     * Internal interface used to confirm an accepted ride offer actually took
     * place by either a rider or driver account*/
    public interface OnConfirmRideListener {
        void onConfirmRide(RideOffer ride);
    }
    /**
     * Required constructor used to create an instance of this class outside of
     * this class.
     * @param acceptedRideOffers which represents the list accepted ride offers
     * to choose from.
     * @param listener which represents an instance of the confirm button (from the
     * ViewAcceptedRideOffers class in this adapter class.*/
    public AcceptedRideOfferAdapter(List<RideOffer> acceptedRideOffers,OnConfirmRideListener listener) {
        this.acceptedRideOffers = acceptedRideOffers;
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // inflate the appropriate layout resource file for accepting a ride offer
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.accepted_ride_offer_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        RideOffer offer = acceptedRideOffers.get(position);
        // Setting up textview to be displayed on accepted ride offers
        holder.textStart.setText("Start: " + offer.startPoint);
        holder.textDestination.setText("Destination: " + offer.destination);
        holder.textDistance.setText("Distance: " + offer.distance + " miles");

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.getDefault());
        holder.textDateTime.setText("Time: " + sdf.format(new Date(offer.availabilityTime)));

        int cost = (int) (offer.distance * 0.5); // Cost = distance * 1/2
        holder.textCost.setText("Cost: $" + cost);

        holder.textStart.setText("From: " + offer.startPoint);
        holder.textDestination.setText("To: " + offer.destination);
        holder.textDistance.setText("Distance: " + offer.distance + " miles");
        holder.textDateTime.setText("Available at: " + sdf.format(new Date(offer.availabilityTime)));
        holder.textCost.setText("Cost in points: " + offer.cost);
        holder.acceptedByEmailText.setText("Accepted by: " + offer.acceptedByEmail);
        holder.driverEmailText.setText("Driver: " + offer.driverEmail);
        holder.confirmButton.setOnClickListener(v -> {
            listener.onConfirmRide(offer);
        });
    }

    @Override
    public int getItemCount() {
        return acceptedRideOffers.size();
    }
    /**
     * Inner class used to grab references to UI elements from the correct
     * layout file and access them when needed*/
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textStart, textDestination, textDistance, textDateTime, textCost,acceptedByEmailText, driverEmailText;
        Button confirmButton;
        public ViewHolder(View itemView) {
            super(itemView);
            textStart = itemView.findViewById(R.id.acceptedStartPoint);
            textDestination = itemView.findViewById(R.id.acceptedDestination);
            textDistance = itemView.findViewById(R.id.acceptedDistance);
            textDateTime = itemView.findViewById(R.id.acceptedAvailability);
            textCost = itemView.findViewById(R.id.acceptedCost);
            acceptedByEmailText = itemView.findViewById(R.id.acceptedByEmailText);
            driverEmailText = itemView.findViewById(R.id.driverEmailText);
            confirmButton = itemView.findViewById(R.id.button4);
        }
    }
}
