package edu.uga.cs.ridesharingapp;

import java.io.Serializable;
/**
 * Model class used to structure RideOffers..*/
public class RideOffer implements Serializable {
    public String id;
    public String startPoint;
    public String destination;
    public double distance;
    public long timestamp;
    public long availabilityTime;
    public String driverEmail;
    public int cost;
    public String acceptedByEmail;
    /**
     * The required default constructor for FireBase purposes*/
    public RideOffer() {}
    /**
     * Main constructor used to create an RideOffer instance outside of this class
     * to be used as cards on the display recycler views of available ride offers
     * to choose from.
     * @param id, which is the id of ride offer
     * @param startPoint which is the starting point of pickup the driver is offering
     * @param destination which is the ending point the driver is offering to drive to.
     * @param distance which is the total distance of the ride offer
     * @param timestamp which is the date in which the ride offer is created
     * @param availabilityTime which is the time that the driver is avaible to
     * offer a specific ride to riders
     * @param driverEmail which is the email of the driver offering a ride
     * @param acceptedByEmail which is the email of the rider who accepts this
     * @param cost which the total cost in points of the ride offer*/
    public RideOffer(String id, String startPoint, String destination, double distance, long timestamp, long availabilityTime, String driverEmail, int cost, String acceptedByEmail) {
        this.id = id;
        this.startPoint = startPoint;
        this.destination = destination;
        this.distance = distance;
        this.timestamp = timestamp;
        this.availabilityTime = availabilityTime;
        this.driverEmail = driverEmail;
        this.cost = cost;
        this.acceptedByEmail = acceptedByEmail;
    }

}
