package edu.uga.cs.ridesharingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
/**
 * This class will be responsible for displaying the second page to riders.
 * Essentially displaying the screen for either creating, updating or deleting
 * ride requests.*/
public class RiderActivity2 extends AppCompatActivity {

    private EditText startInput, destInput, distInput, availabilityInput;
    private Button submitBtn;
    private RecyclerView recyclerView;
    private List<RideRequest> rideRequests;
    private RideRequestAdapter adapter;
    private DatabaseReference dbRef;
    private String editRequestId = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_rider2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // Have the user logout when they click on the logout button
        Button logoutButton = findViewById(R.id.logoutButtonRiderActivity2);
        logoutButton.setOnClickListener((View v) -> {
            FirebaseAuth.getInstance().signOut();  // Sign out the user from FireBase
            // Show a confirmation toast message
            Toast.makeText(RiderActivity2.this, "Logged out successfully", Toast.LENGTH_SHORT).show();

            // Redirect the user to the Splash screen and clear back stack
            Intent intent = new Intent(RiderActivity2.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();

        }); //logoutButton
        // Have the user go back to RiderActivity1 when they click on the back button
        Button backButton = findViewById(R.id.backButtonRider2);
        backButton.setOnClickListener((View v) -> {
            Intent i = new Intent(this, RiderActivity1.class);
            startActivity(i);
        });
        // Have the user transition to the screen to see already accepted
        // ride requests.
        Button acceptedRideRequests = findViewById(R.id.button9);
        acceptedRideRequests.setOnClickListener((View v) -> {
            Intent i = new Intent(this, ViewAcceptedRideRequests.class);
            startActivity(i);
        });

        startInput = findViewById(R.id.editTextStart);
        destInput = findViewById(R.id.editTextDestination);
        distInput = findViewById(R.id.editTextDistance);
        availabilityInput = findViewById(R.id.editTextAvailability);
        submitBtn = findViewById(R.id.buttonSubmitRequest);
        recyclerView = findViewById(R.id.recyclerViewRequests);

        rideRequests = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new RideRequestAdapter(rideRequests, "rider", new RideRequestAdapter.OnRideRequestClickListener() {
            @Override
            public void onEditClick(RideRequest rideRequest) {
                showEditDialog(rideRequest);
            }

            @Override
            public void onDeleteClick(RideRequest rideRequest) {
                deleteRideRequest(rideRequest);
            }

            @Override
            public void onAcceptClick(RideRequest rideRequest) {}
        });
        recyclerView.setAdapter(adapter);

        dbRef = FirebaseDatabase.getInstance().getReference("RideRequests");
        // get the Firebase reference to the "RideRequests" node
        submitBtn.setOnClickListener(v -> {
            String start = startInput.getText().toString().trim();
            String dest = destInput.getText().toString().trim();
            String distStr = distInput.getText().toString().trim();
            String availStr = availabilityInput.getText().toString().trim();
            long availTime;
            // User is required to fill all the text fields when creating a new ride request
            if (start.isEmpty() || dest.isEmpty() || distStr.isEmpty() || availStr.isEmpty()) {
                Toast.makeText(this, "Fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            double distance = Double.parseDouble(distStr);
            long timestamp = System.currentTimeMillis();
            try {
                availTime = new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(availStr).getTime();
            } catch (ParseException e) {
                Toast.makeText(this, "Invalid date/time format", Toast.LENGTH_SHORT).show();
                return;
            }

            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            //String email = user != null ? user.getEmail() : "";
            String email = FirebaseAuth.getInstance().getCurrentUser().getEmail();
            // Grab the email of the current logged in user
            if (editRequestId == null) {
                String id = dbRef.push().getKey();
                RideRequest request = new RideRequest(id, start, dest, distance, timestamp, availTime, email);
                dbRef.child(id).setValue(request);
            } else {
                RideRequest request = new RideRequest(editRequestId, start, dest, distance, timestamp, availTime, email);
                dbRef.child(editRequestId).setValue(request);
                editRequestId = null;
                submitBtn.setText("Submit Ride Request");
            }

            startInput.setText("");
            destInput.setText("");
            distInput.setText("");
            availabilityInput.setText("");
        });

        loadRideRequests();
    } //onCreate
    /**
     * Private helper function that will be used to load current unaccepted
     * ride requests from the database.*/
    private void loadRideRequests() {
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                rideRequests.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    RideRequest request = snap.getValue(RideRequest.class);
                    rideRequests.add(request);
                }
                /*
                Collections.sort(rideRequests, (a, b) -> {
                    if (a.distance != b.distance) {
                        return Double.compare(a.distance, b.distance);
                    } else {
                        return Long.compare(a.timestamp, b.timestamp);
                    }
                }); */

                Collections.sort(rideRequests, (a, b) -> {
                    if (a.availabilityTime != b.availabilityTime) {
                        return Long.compare(a.availabilityTime, b.availabilityTime); // Earlier availability first
                    } else {
                        return Double.compare(a.distance, b.distance); // Smaller distance second
                    }
                });

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    } //loanRideRequests

    /**
     * Function that will be used to display and render the edit dialog
     * box for editing Ride Requests.
     * @param request which represents the current ride request the user
     * decides they want to edit*/
    private void showEditDialog(RideRequest request) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Ride Request");
        //Inflate the dialog_edit_request.xml file for laying out the format for editting
        // ride requests
        View viewInflated = LayoutInflater.from(this).inflate(R.layout.dialog_edit_request, (ViewGroup) findViewById(android.R.id.content), false);

        final EditText inputStart = viewInflated.findViewById(R.id.editStartPoint);
        final EditText inputDestination = viewInflated.findViewById(R.id.editDestination);
        final EditText inputDistance = viewInflated.findViewById(R.id.editDistance);
        final EditText editAvailability = viewInflated.findViewById(R.id.editTextAvailability);

        inputStart.setText(request.startPoint);
        inputDestination.setText(request.destination);
        inputDistance.setText(String.valueOf(request.distance));
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
        editAvailability.setText(sdf.format(new Date(request.availabilityTime)));

        builder.setView(viewInflated);
        // Upon the user clicking on the save button when they are done
        // editing the ride request, then check if their info entered into the
        // edit textboxes are valid inputs, and save it to memory.
        builder.setPositiveButton("Save", (dialog, which) -> {
            String updatedStart = inputStart.getText().toString().trim();
            String updatedDest = inputDestination.getText().toString().trim();
            double updatedDist;
            String newAvailabilityStr = editAvailability.getText().toString().trim();

            try {
                updatedDist = Double.parseDouble(inputDistance.getText().toString().trim());
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid distance input.", Toast.LENGTH_SHORT).show();
                return;
            }

            long newAvailabilityTime;
            try {
                newAvailabilityTime = sdf.parse(newAvailabilityStr).getTime();
            } catch (ParseException e) {
                Toast.makeText(this, "Invalid availability format", Toast.LENGTH_SHORT).show();
                return;
            }

            DatabaseReference rideRef = FirebaseDatabase.getInstance().getReference("RideRequests").child(request.id);
            rideRef.child("startPoint").setValue(updatedStart);
            rideRef.child("destination").setValue(updatedDest);
            rideRef.child("distance").setValue(updatedDist);
            rideRef.child("availabilityTime").setValue(newAvailabilityTime);
            Toast.makeText(this, "Ride request updated.", Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }
    /**
     * Function that will be responsible for managing deleting of a ride request
     * from both the database and the screen.*/
    private void deleteRideRequest(RideRequest rideRequest) {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("RideRequests").child(rideRequest.id);
        ref.removeValue().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(this, "Ride request deleted", Toast.LENGTH_SHORT).show();
            }
        });
    }
} //RideActivity2